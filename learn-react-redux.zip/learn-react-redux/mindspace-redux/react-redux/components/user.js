import React, { Component } from 'react'

export default class User extends Component{
  render(){
   return <div>
      <h1>{this.props.userName}</h1>
      <button onClick={() => this.props.change('abb')}>change</button>
    </div>
  }
}