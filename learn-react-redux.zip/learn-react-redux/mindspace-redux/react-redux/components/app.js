import React, { Component } from 'react'
import User from './user.js'
import { connect } from 'react-redux'
import { setName } from '../actions/userActions'
class App extends Component{
  render(){
    return(
      <User userName={this.props.user.name} change={this.props.setName.bind(this)} />
    )
  }
}

const mapStateToProps = (state) => {
  return {
    user: state.user,
    math: state.math
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    setName: (name) => {
      dispatch(setName(name));
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App)