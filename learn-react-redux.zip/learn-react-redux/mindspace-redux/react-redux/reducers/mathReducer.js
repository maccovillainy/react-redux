const mathReducer = (state = {
  result: 1,
  lastValues: []
}, action) => {
  switch (action.type){
    case 'PLUS':
      state = Object.assign({}, state, {
        result: state.result + action.payload,
        lastValues: [...state.lastValues, action.payload]
      })
      break;
      case 'A':
      state = Object.assign({}, state, {
        result: action.payload,
        lastValues: [...state.lastValues, action.payload]
      })
  }
  return state
}

export default mathReducer