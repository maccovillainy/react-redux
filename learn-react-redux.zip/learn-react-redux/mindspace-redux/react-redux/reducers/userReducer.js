const userReducer = (state = {
  name: 'max',
  age: 22
}, action) => {
  switch (action.type){
    case 'SET_NAME':
      state = Object.assign({}, state, {
        name: action.payload
      });
      break;
  }
  return state
}
 export default userReducer