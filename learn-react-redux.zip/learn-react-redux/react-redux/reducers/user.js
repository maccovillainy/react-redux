const initialState  = {
    name: 'Аноним'
}
export  default function  user(state  = initialState) {
    return  state
}